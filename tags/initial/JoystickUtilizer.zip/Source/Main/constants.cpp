#include "constants.h"

const char *kAppSignature	= "application/x-vnd.pecora-joystickutilizer";
const char *kPortName		= "joystick utilizer device port";
const char *kNoJoystick		= "No joystick was found.";
const char *kPrefsFileName	= "JoystickUtilizer_settings";

