#ifndef _SETTINGS_WINDOW_H
#define _SETTINGS_WINDOW_H

#include <Message.h>
#include <Window.h>

class SettingsWindow : public BWindow {

public:
				SettingsWindow();
				~SettingsWindow();
				
	void		MessageReceived(BMessage *message);
	
};

#endif