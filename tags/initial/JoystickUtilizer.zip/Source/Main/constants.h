#ifndef _CONSTANTS_H
#define _CONSTANTS_H

extern const char *kAppSignature;
extern const char *kPortName;
extern const char *kNoJoystick;
extern const char *kPrefsFileName;

#endif