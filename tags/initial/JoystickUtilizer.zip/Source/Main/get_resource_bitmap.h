#ifndef _GET_RESOURCE_BITMAP_H
#define _GET_RESOURCE_BITMAP_H

class BBitmap;

BBitmap *get_resource_bitmap(const char *name);

#endif