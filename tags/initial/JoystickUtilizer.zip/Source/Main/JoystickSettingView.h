#ifndef _JOYSTICK_SETTING_VIEW_H
#define _JOYSTICK_SETTING_VIEW_H

#include <View.h>

class BBitmap;

class JoystickSettings;
class TextField;

class JoystickSettingView : public BView {

public:
	
						JoystickSettingView( BRect frame, const char *name, uint8 joystick_nr );
						~JoystickSettingView();
	
	void				UpdateTextFields();
			
	void				MouseDown( BPoint where );
	void				Draw( BRect updateRect );

	void				Pulse();
			
private:

	BBitmap				*fJoystickBmp, *fButtonBmp, *fButtonActiveBmp;
	TextField			*fTextField[20];

	uint8				fJoystickNr;
	JoystickSettings	*fJoystickSettings;

	int32				fNumButtons;
};

#endif