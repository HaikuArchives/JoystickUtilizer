#ifndef _NEW_PRESET_WINDOW_H
#define _NEW_PRESET_WINDOW_H

#include <Window.h>

class NewPresetWindow : public BWindow
{

public:

				NewPresetWindow( BLooper *target );

void			MessageReceived(BMessage *message);


private:

BLooper			*fTarget;

};

#endif