#ifndef _MAIN_VIEW_H
#define _MAIN_VIEW_H

#include <View.h>

class BBitmap;

class MainView : public BView {

public:

		MainView( BRect frame );
		
void	AttachedToWindow();

void	MouseDown( BPoint where );
void	Draw( BRect updateRect );
		
};

#endif